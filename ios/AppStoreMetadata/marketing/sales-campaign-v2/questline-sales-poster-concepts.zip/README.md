# Questline sales campaign — concept proofs

Ordered four-poster campaign in the selected orange-and-white direction.

1. Your next sale. On your lock screen.
2. Purchases. Renewals. Progress.
3. All your apps. One place.
4. Choose your sales alerts.

These Image Generation proofs preserve the chosen marketing direction. They are not upload-ready App Store screenshots: screen content is illustrated from source captures, some captures predate the current app, and the generated dimensions differ from the 1320 × 2868 target. Before submission, compose the final exports using the final candidate’s real screens and validate dimensions and text. The lock-screen scene is explicitly illustrative sample notification content.

The previous campaign and upload ZIP remain separate. No App Store Connect changes or uploads were made.
